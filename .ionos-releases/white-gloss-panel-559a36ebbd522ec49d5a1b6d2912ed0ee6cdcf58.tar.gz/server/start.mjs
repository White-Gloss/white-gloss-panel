import {createServer} from 'node:http';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {createApplication,applicationEnvironment} from './application.mjs';
import {chatNotificationsSettled} from './chat.mjs';
export function assertIonosRuntime(variables=process.env,platform=process.platform,cwd=process.cwd()){
  if(platform!=='linux'||!cwd.startsWith('/srv/white-gloss-panel/')||variables.NODE_ENV!=='production'||variables.PANEL_BIND!=='127.0.0.1'||!/^\/var\/lib\/white-gloss-panel\//.test(variables.PANEL_DATA_DIR??''))throw Error('WG_LOCAL_HOSTING_BLOCKED: Der Panelserver darf ausschließlich im freigegebenen IONOS-Verzeichnis starten.');
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===resolve(process.argv[1])){
  assertIonosRuntime();process.umask(0o077);const env=await applicationEnvironment();const app=await createApplication(env);const port=Number(env.PANEL_PORT??3101);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Ungültiger Port.');
  // Request bodies are held in memory; all of them together stay below 96 MB so parallel uploads cannot exhaust the 512 MB service limit.
  let buffered=0;const BUFFER_LIMIT=96*1024*1024;
  const server=createServer(async(incoming,outgoing)=>{let size=0;try{const chunks=[];for await(const chunk of incoming){size+=chunk.length;buffered+=chunk.length;if(size>16*1024*1024){outgoing.writeHead(413);outgoing.end('Anfrage zu groß');return;}if(buffered>BUFFER_LIMIT){outgoing.writeHead(503,{'Retry-After':'10'});outgoing.end('Server ausgelastet. Bitte gleich erneut versuchen.');return;}chunks.push(chunk);}const headers=new Headers();for(const [key,value] of Object.entries(incoming.headers))if(value!==undefined)headers.set(key,Array.isArray(value)?value.join(','):value);headers.delete('oai-authenticated-user-email');const target=new URL(incoming.url,env.PANEL_ORIGIN);if(target.origin!==env.PANEL_ORIGIN){outgoing.writeHead(400);outgoing.end();return;}const request=new Request(target,{method:incoming.method,headers,...(!['GET','HEAD'].includes(incoming.method)?{body:Buffer.concat(chunks)}:{})});const response=await app.fetch(request);outgoing.writeHead(response.status,Object.fromEntries(response.headers));if(incoming.method==='HEAD'||!response.body){outgoing.end();return;}for await(const chunk of response.body)if(!outgoing.write(chunk))await new Promise(resolve=>outgoing.once('drain',resolve));outgoing.end();}catch{if(!outgoing.headersSent)outgoing.writeHead(500);outgoing.end('Verarbeitung fehlgeschlagen.');}finally{buffered-=size;}});
  server.headersTimeout=10000;server.requestTimeout=180000;server.keepAliveTimeout=5000;server.listen(port,'127.0.0.1',()=>console.log('White-Gloss-Panel bereit.'));for(const signal of ['SIGTERM','SIGINT'])process.once(signal,()=>server.close(async()=>{await chatNotificationsSettled();env.DB.close();process.exit(0);}));
}
